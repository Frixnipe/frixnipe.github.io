execute as @a if score @s started matches 1 if entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] run scoreboard players add @s laps 1
execute as @a if score @s started matches 1 if entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] if score @s laps < @s laps_total run title @s actionbar [{"score":{"name":"*","objective":"laps"},"color":"aqua"},{"text":". kör","color":"aqua"}]
execute as @a if score @s started matches 1 if entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] unless score @s checkpoint matches 3 run title @s actionbar [{"text":"Kihagytál egy checkpointot vagy rossz irányba mentél.","color":"#ff8080"}]
execute as @a if score @s started matches 1 if entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] unless score @s checkpoint matches 3 run function fri:reset
execute as @a if score @s started matches 1 if entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] if score @s laps = @s laps_total if score @s laps matches 2 run function fri:finish1
execute as @a if score @s started matches 1 if entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] if score @s laps = @s laps_total if score @s laps matches 4 run function fri:finish3
execute as @a if score @s started matches 1 if entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] if score @s laps = @s laps_total if score @s laps matches 11 run function fri:finish10
# these would be useful for individual lap times in multi-lap trials, but that's not what we're meant to count here
# execute as @a if score @s started matches 1 if entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] run scoreboard players set @s m 0
# execute as @a if score @s started matches 1 if entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] run scoreboard players set @s s 0
# execute as @a if score @s started matches 1 if entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] run scoreboard players set @s ms 0
execute as @a unless score @s started matches 2 if entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] run scoreboard players set @s started 2

execute as @a if score @s started matches 2 unless entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] run scoreboard players set @s checkpoint 1
execute as @a if score @s started matches 2 unless entity @s[x=-148,y=-60,z=-41,dx=8,dy=4,dz=14] run scoreboard players set @s started 1

execute as @a if score @s started matches 1 if entity @s[x=57,y=-60,z=-113,dx=8,dy=4,dz=12] run title @s actionbar [{"text":"Idő: ","color":"#80ff80"},{"score":{"name":"*","objective":"m"}},{"text":":"},{"score":{"name":"*","objective":"s"}},{"text":":"},{"score":{"name":"*","objective":"ms"}}]
execute as @a if score @s started matches 1 if entity @s[x=57,y=-60,z=-113,dx=8,dy=4,dz=12] unless score @s checkpoint matches 1 run title @s actionbar [{"text":"Kihagytál egy checkpointot vagy rossz irányba mentél.","color":"#ff8080"}]
execute as @a if score @s started matches 1 if entity @s[x=57,y=-60,z=-113,dx=8,dy=4,dz=12] unless score @s checkpoint matches 1 run function fri:reset
execute as @a if score @s started matches 1 if entity @s[x=57,y=-60,z=-113,dx=8,dy=4,dz=12] run scoreboard players set @s started 3

execute as @a if score @s started matches 3 unless entity @s[x=57,y=-60,z=-113,dx=8,dy=4,dz=12] run scoreboard players set @s checkpoint 2
execute as @a if score @s started matches 3 unless entity @s[x=57,y=-60,z=-113,dx=8,dy=4,dz=12] run scoreboard players set @s started 1

execute as @a if score @s started matches 1 if entity @s[x=-111,y=-58,z=-22,dx=15,dy=5,dz=-9] run title @s actionbar [{"text":"Idő: ","color":"#80ff80"},{"score":{"name":"*","objective":"m"}},{"text":":"},{"score":{"name":"*","objective":"s"}},{"text":":"},{"score":{"name":"*","objective":"ms"}}]
execute as @a if score @s started matches 1 if entity @s[x=-111,y=-58,z=-22,dx=15,dy=5,dz=-9] unless score @s checkpoint matches 2 run title @s actionbar [{"text":"Kihagytál egy checkpointot vagy rossz irányba mentél.","color":"#ff8080"}]
execute as @a if score @s started matches 1 if entity @s[x=-111,y=-58,z=-22,dx=15,dy=5,dz=-9] unless score @s checkpoint matches 2 run function fri:reset
execute as @a if score @s started matches 1 if entity @s[x=-111,y=-58,z=-22,dx=15,dy=5,dz=-9] run scoreboard players set @s started 4

execute as @a if score @s started matches 4 unless entity @s[x=-111,y=-58,z=-22,dx=15,dy=5,dz=-9] run scoreboard players set @s checkpoint 3
execute as @a if score @s started matches 4 unless entity @s[x=-111,y=-58,z=-22,dx=15,dy=5,dz=-9] run scoreboard players set @s started 1

execute as @a if score @s laps matches 1.. run scoreboard players add @s t 1
execute as @a if score @s laps matches 1.. run scoreboard players add @s ms 5
execute as @a if score @s ms matches 100 run scoreboard players add @s s 1
execute as @a if score @s ms matches 100 run scoreboard players set @s ms 0
execute as @a if score @s s matches 60 run scoreboard players add @s m 1
execute as @a if score @s s matches 60 run scoreboard players set @s s 0

execute as @e[type=#minecraft:boat] at @s if entity @n[type=minecraft:player,distance=1..] run kill @s

execute as @a if score @s laps matches 1.. if score @s started matches 1 run title @s actionbar [{"text":"Idő: "},{"score":{"name":"*","objective":"m"}},{"text":":"},{"score":{"name":"*","objective":"s"}},{"text":":"},{"score":{"name":"*","objective":"ms"}}]

execute as @a at @s unless score @s started matches 0 unless score @s laps_total matches 0 unless entity @n[type=#minecraft:boat,distance=..1] run title @s actionbar [{"text":"Elhagytad a csónakot.","color":"#ff8080"}]
execute as @a at @s unless score @s started matches 0 unless score @s laps_total matches 0 unless entity @n[type=#minecraft:boat,distance=..1] run function fri:reset