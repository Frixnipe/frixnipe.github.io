scoreboard players set @s checkpoint 3
scoreboard players set @s started 1
scoreboard players set @s laps 0
scoreboard players set @s m 0
scoreboard players set @s s 0
scoreboard players set @s ms 0
scoreboard players set @s t 0
scoreboard players set @s laps_total 2
summon minecraft:spruce_boat -162 -60 -36 {Rotation:[-90, 0]}
ride @s mount @n[type=minecraft:spruce_boat]
tellraw @s [{"text":"§eEgy kört kell tegyél a pályán.\n§cBármikor kiléphetsz a csónak elhagyásával.\n§bAz időzítő az első checkpoint megérintésével indul.\n§e§lSok szerencsét!"}]
