scoreboard objectives add m dummy
scoreboard objectives add s dummy
scoreboard objectives add ms dummy
scoreboard objectives add t dummy
scoreboard objectives add m1 dummy
scoreboard objectives add s1 dummy
scoreboard objectives add ms1 dummy
scoreboard objectives add t1 dummy
scoreboard objectives add m3 dummy
scoreboard objectives add s3 dummy
scoreboard objectives add ms3 dummy
scoreboard objectives add t3 dummy
scoreboard objectives add m10 dummy
scoreboard objectives add s10 dummy
scoreboard objectives add ms10 dummy
scoreboard objectives add t10 dummy
scoreboard objectives add started dummy
scoreboard objectives add checkpoint dummy
scoreboard objectives add laps dummy
scoreboard objectives add laps_total dummy
scoreboard objectives add tmp dummy

kill @e[type=text_display,tag=d1]
kill @e[type=text_display,tag=d3]
kill @e[type=text_display,tag=d10]
kill @e[type=text_display,tag=map]

summon text_display -104 -15 -45 {Tags: ["d1"],Rotation:[-45,0],"text":"§eMenj egyet az egykörös kihíváson, hogy frissítsd ezt a toplistát!"}
summon text_display -101 -15 -47 {Tags: ["d3"],Rotation:[0,0],"text":"§eMenj egyet a háromkörös kihíváson, hogy frissítsd ezt a toplistát!"}
summon text_display -98 -15 -45 {Tags: ["d10"],Rotation:[45,0],"text":"§eMenj egyet a tízkörös kihíváson, hogy frissítsd ezt a toplistát!"}
summon text_display -106 -13 -42 {Tags: ["map"],Rotation:[-90,0],"text":"§fTérkép"}