scoreboard players set @s checkpoint 3
scoreboard players set @s started 0
scoreboard players set @s laps 0
kill @s

# write out score and stuff in chat
execute unless score @s t < @s t3 run tellraw @s [{"score":{"name":"@s","objective":"m"}},{"text":":"},{"score":{"name":"@s","objective":"s"}},{"text":":"},{"score":{"name":"@s","objective":"ms"}},{"text":"§e idővel fejeztél be három kört. Gratulálok!"}]
execute if score @s t < @s t3 run tellraw @s [{"score":{"name":"@s","objective":"m"}},{"text":":"},{"score":{"name":"@s","objective":"s"}},{"text":":"},{"score":{"name":"@s","objective":"ms"}},{"text":"§e idővel fejeztél be három kört, §és ezzel új személyes rekordot állítottál! §eGratulálok!"}]

# if it's a new record, set it as such
execute if score @s t < @s t3 run scoreboard players operation @s m3 = @s m
execute if score @s t < @s t3 run scoreboard players operation @s s3 = @s s
execute if score @s t < @s t3 run scoreboard players operation @s ms3 = @s ms
execute if score @s t < @s t3 run scoreboard players operation @s t3 = @s t

# if it's a first time, still set it as new record
execute if score @s t3 matches 0 run scoreboard players operation @s m3 = @s m
execute if score @s t3 matches 0 run scoreboard players operation @s s3 = @s s
execute if score @s t3 matches 0 run scoreboard players operation @s ms3 = @s ms
execute if score @s t3 matches 0 run scoreboard players operation @s t3 = @s t

# reset timers for next time (even if I also reset them on start; better safe than sorry!)
scoreboard players set @s m 0
scoreboard players set @s s 0
scoreboard players set @s ms 0
scoreboard players set @s t 0
scoreboard players set @s laps_total 0

# remove tags from top 5 top players
tag @a remove t1
tag @a remove t2
tag @a remove t3
tag @a remove t4
tag @a remove t5
execute as @a run scoreboard players operation @s tmp = @s t3

# get top 1
scoreboard players set #top tmp 65535
execute as @a run scoreboard players operation #top tmp < @s tmp
execute as @a[limit=1] if score @s tmp = #top tmp run tag @s add t1
execute as @a[limit=1] if score @s tmp = #top tmp run scoreboard players reset @s tmp

# get top 2
scoreboard players set #top tmp 65535
execute as @a run scoreboard players operation #top tmp < @s tmp
execute as @a[limit=1] if score @s tmp = #top tmp run tag @s add t2
execute as @a[limit=1] if score @s tmp = #top tmp run scoreboard players reset @s tmp

# get top 3
scoreboard players set #top tmp 65535
execute as @a run scoreboard players operation #top tmp < @s tmp
execute as @a[limit=1] if score @s tmp = #top tmp run tag @s add t3
execute as @a[limit=1] if score @s tmp = #top tmp run scoreboard players reset @s tmp

# get top 4
scoreboard players set #top tmp 65535
execute as @a run scoreboard players operation #top tmp < @s tmp
execute as @a[limit=1] if score @s tmp = #top tmp run tag @s add t4
execute as @a[limit=1] if score @s tmp = #top tmp run scoreboard players reset @s tmp

# get top 5
scoreboard players set #top tmp 65535
execute as @a run scoreboard players operation #top tmp < @s tmp
execute as @a[limit=1] if score @s tmp = #top tmp run tag @s add t5
execute as @a[limit=1] if score @s tmp = #top tmp run scoreboard players reset @s tmp

# the following line of code is about 1850 characters long. there is a reason I only display the top 5
# modify display entity to display updated top 5
execute as @e[type=text_display,tag=d3] at @s run data modify entity @s text set value [{"text":"§f§l3 KÖR\n\n"},{"text":"§7#1: "},{"selector":"@a[tag=t1,limit=1]","color":"yellow"},{"text":"§b ("},{"score":{"name":"@a[tag=t1,limit=1]","objective":"m3","color":"cyan"}},{"text":"§b:"},{"score":{"name":"@a[tag=t1,limit=1]","objective":"s3","color":"cyan"}},{"text":"§b:"},{"score":{"name":"@a[tag=t1,limit=1]","objective":"ms3","color":"cyan"}},{"text":"§b)\n"},{"text":"§7#2: "},{"selector":"@a[tag=t2,limit=1]","color":"yellow"},{"text":"§b ("},{"score":{"name":"@a[tag=t2,limit=1]","objective":"m3","color":"cyan"}},{"text":"§b:"},{"score":{"name":"@a[tag=t2,limit=1]","objective":"s3","color":"cyan"}},{"text":"§b:"},{"score":{"name":"@a[tag=t2,limit=1]","objective":"ms3","color":"cyan"}},{"text":"§b)\n"},{"text":"§7#3: "},{"selector":"@a[tag=t3,limit=1]","color":"yellow"},{"text":"§b ("},{"score":{"name":"@a[tag=t3,limit=1]","objective":"m3","color":"cyan"}},{"text":"§b:"},{"score":{"name":"@a[tag=t3,limit=1]","objective":"s3","color":"cyan"}},{"text":"§b:"},{"score":{"name":"@a[tag=t3,limit=1]","objective":"ms3","color":"cyan"}},{"text":"§b)\n"},{"text":"§7#4: "},{"selector":"@a[tag=t4,limit=1]","color":"yellow"},{"text":"§b ("},{"score":{"name":"@a[tag=t4,limit=1]","objective":"m3","color":"cyan"}},{"text":"§b:"},{"score":{"name":"@a[tag=t4,limit=1]","objective":"s3","color":"cyan"}},{"text":"§b:"},{"score":{"name":"@a[tag=t4,limit=1]","objective":"ms3","color":"cyan"}},{"text":"§b)\n"},{"text":"§7#5: "},{"selector":"@a[tag=t5,limit=1]","color":"yellow"},{"text":"§b ("},{"score":{"name":"@a[tag=t5,limit=1]","objective":"m3","color":"cyan"}},{"text":"§b:"},{"score":{"name":"@a[tag=t5,limit=1]","objective":"s3","color":"cyan"}},{"text":"§b:"},{"score":{"name":"@a[tag=t5,limit=1]","objective":"ms3","color":"cyan"}},{"text":"§b)\n"}]