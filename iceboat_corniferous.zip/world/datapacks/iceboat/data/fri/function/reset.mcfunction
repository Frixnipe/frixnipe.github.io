scoreboard players set @s checkpoint 3
scoreboard players set @s started 0
scoreboard players set @s laps 0
scoreboard players set @s m 0
scoreboard players set @s s 0
scoreboard players set @s ms 0
scoreboard players set @s t 0
scoreboard players set @s laps_total 0
kill @s